<?php
/**
 * Created by PhpStorm.
 * User: hlz
 * Date: 16-8-3
 * Time: 下午9:11
 */

namespace App\Repositories;


abstract class Repository
{
    public function __construct()
    {
    }
}