<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf_token" content="<?php echo e(csrf_token()); ?>"/>

    <link rel="shortcut icon" href="<?php echo e(asset('favicon.ico')); ?>">
    <title><?php echo e(trans('general.pageTitle')); ?></title>

    <?php if(App::environment('development')): ?>
        <link rel="stylesheet/less" type="text/css" href="/resources/assets/less/yang/theme/<?php echo e($theme); ?>.less">
        <link rel="stylesheet/less" type="text/css" href="/resources/assets/less/yang/yang-home.less">
        <script src="/resources/assets/less/less.min.js"></script>
    <?php else: ?>
        <link href="<?php echo e(URL::asset('/css/yang-home.css')); ?>" rel="stylesheet">
        <link href="<?php echo e(URL::asset('/css/theme/' . $theme . '.css')); ?>" rel="stylesheet">
    <?php endif; ?>

</head>
<body id="yang-home">

<?php echo $__env->yieldContent('content'); ?>

</body>
</html>
