<?php $__env->startSection('content'); ?>

    <?php /*跳转到space*/ ?>
    <div class="panel">
        <a href=""><?php echo e(trans('general.space')); ?></a>
    </div>
    <?php /*根据登陆状态显示登陆或登出*/ ?>
    <?php if($user): ?>
        <div class="panel" id="logout">
            <?php echo e(trans('general.logout')); ?>

        </div>
    <?php else: ?>
        <div class="panel" id="login">
            <?php echo e(trans('general.login')); ?>

        </div>
    <?php endif; ?>

    <?php foreach($spaces as $space): ?>

        <div class="space circle1 med-btn">
            <a href="<?php echo e(route('space', ['space_id' => $space->space_id])); ?>"><?php echo e($space->name); ?></a>
        </div>

    <?php endforeach; ?>


    <?php /*根据登陆状态显示用户头像或者是登陆输入框*/ ?>
    <div class="portrait" id="portrait">

        <?php if($user): ?>
            <img src="<?php echo e(asset('portrait/' . $user->profile->portrait)); ?>" title="<?php echo e($user->name); ?>">
        <?php else: ?>
            <form enctype="multipart/form-data" class="portrait-form" id="portrait_form">

                <input type="email" name="email" value="<?php echo e(old('email')); ?>">
                <?php if($errors->has('email')): ?>
                    <span class="help-block">
                <strong><?php echo e($errors->first('email')); ?></strong>
            </span>
                <?php endif; ?>
                <input type="password" name="password">
                <?php if($errors->has('password')): ?>
                    <span class="help-block">
                <strong><?php echo e($errors->first('password')); ?></strong>
            </span>
                <?php endif; ?>
                <div class="remember-box">
                    <label for="remember">
                        <input id="remember" type="checkbox" name="remember">
                        <span><?php echo e(trans('general.remember')); ?></span>
                    </label>
                </div>

            </form>
        <?php endif; ?>

    </div><!-- #portrait.portrait ends -->

    <input type="hidden" id="login_url" value="<?php echo e(route('login')); ?>">
    <input type="hidden" id="logout_url" value="<?php echo e(route('logout')); ?>">

    <?php if(App::environment('development')): ?>
        <script data-main="/resources/assets/js/yang/yang-home.js" src="/resources/assets/js/require.js"></script>
        <script type="text/javascript">
            require.config({
                               urlArgs: "v=" + (new Date()).getTime()
                           });
        </script>
    <?php else: ?>
        <script src="<?php echo e(URL::asset('/js/yang-home.js')); ?>"></script>
    <?php endif; ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.yang.home', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>