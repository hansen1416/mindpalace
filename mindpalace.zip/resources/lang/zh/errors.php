<?php

return [
    'invalid_ctg_pid' => '分类元素的父级分类，不能是自己的子元素',
];