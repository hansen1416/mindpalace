<?php

return [
    'pageTitle' => 'Mind Palace',
    'home'      => 'Home',
    'space'     => 'Space',
    'login'     => 'Login',
    'logout'    => 'Logout',
    'remember'  => 'Remember Me',
];
