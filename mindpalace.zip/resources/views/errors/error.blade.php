<div class="lintel">
    <span id="errorBar"></span>
</div>