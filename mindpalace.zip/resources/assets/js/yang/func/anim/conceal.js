define(function() {
    /**
     * 隐藏元素
     */
    return function (element){
        element.style['display'] = 'none';
    }

});