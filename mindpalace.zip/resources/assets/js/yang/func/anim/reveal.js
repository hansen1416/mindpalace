define(function() {
    /**
     * 显示元素
     */
    return function (element){
        element.style['display'] = 'block';
    }

});