define(function(){
    return  window.cancelAnimationFrame            		||
	        window.webkitCancelRequestAnimationFrame    ||
	        window.mozCancelRequestAnimationFrame       ||
	        window.oCancelRequestAnimationFrame        	||
	        window.msCancelRequestAnimationFrame        ||
	        clearTimeout;
})