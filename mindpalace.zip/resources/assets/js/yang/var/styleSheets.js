define( function() {
	return document.styleSheets[0];
} );